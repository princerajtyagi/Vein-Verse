from django.db import models


# Create your models here.


class Course(models.Model):
    course_id = models.AutoField(primary_key=True)
    cname = models.CharField(max_length=100)
    fee = models.IntegerField()
    duration = models.CharField(max_length=20)


    def __str__(self):
        return self.cname


class Student(models.Model):
    roll = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    address = models.CharField(max_length=50)
    gender = models.CharField(max_length=10)  # e.g., Male, Female, Other
    courses = models.ManyToManyField(Course)  # many to many relationship
    qualification = models.CharField(max_length=50)